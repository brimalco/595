For project1b, we will be implementing KILL
